import random
nums = [x for x in range(10)]
random.shuffle(nums)
nums
[6, 3, 5, 4, 0, 1, 2, 9, 8, 7]
