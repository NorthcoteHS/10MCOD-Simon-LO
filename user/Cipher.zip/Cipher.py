Door = input ('')
number = ord(Door)
print(Door,"=", number)
